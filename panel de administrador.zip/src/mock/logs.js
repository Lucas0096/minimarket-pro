export const defaultLogs = [
  { id: 1, date: Date.now() - 1000 * 60 * 60 * 24 * 5, activity: 'Mercado "Mercado Central" agregado', marketId: 'market1', userId: 'admin' },
  { id: 2, date: Date.now() - 1000 * 60 * 60 * 24 * 3, activity: 'Usuario "vendedor1" creado', marketId: 'market1', userId: 'admin' },
  { id: 3, date: Date.now() - 1000 * 60 * 60 * 24 * 1, activity: 'Suscripción de "Mercado del Sol" extendida', marketId: 'market2', userId: 'admin' },
  { id: 4, date: Date.now() - 1000 * 60 * 30, activity: 'Permiso de "ventas" para rol "vendedor" modificado', marketId: null, userId: 'admin' },
  { id: 5, date: Date.now() - 1000 * 60 * 10, activity: 'Rol "colaborador" agregado', marketId: null, userId: 'admin' },
];