export const mockData = {
  markets: [
    { id: 'market1', name: 'Mercado Central', lastConnection: Date.now() - 1000 * 60 * 5, subscriptionEndDate: new Date(new Date().getFullYear(), new Date().getMonth(), 5).getTime() + 1000 * 60 * 60 * 24 * 10, ownerName: 'Juan', ownerLastName: 'Pérez', ownerDNI: '12345678A', ownerPhone: '5512345678', ownerEmail: 'juan.perez@example.com', address: 'Calle Falsa 123', mapLocation: 'https://maps.google.com/?q=Calle+Falsa+123' },
    { id: 'market2', name: 'Mercado del Sol', lastConnection: Date.now() - 1000 * 60 * 60 * 25, subscriptionEndDate: new Date(new Date().getFullYear(), new Date().getMonth(), 5).getTime() + 1000 * 60 * 60 * 24 * 60, ownerName: 'María', ownerLastName: 'García', ownerDNI: '87654321B', ownerPhone: '5587654321', ownerEmail: 'maria.garcia@example.com', address: 'Avenida Siempre Viva 742', mapLocation: 'https://maps.google.com/?q=Avenida+Siempre+Viva+742' },
    { id: 'market3', name: 'Mercado de la Luna', lastConnection: Date.now() - 1000 * 60 * 60 * 24 * 30, subscriptionEndDate: new Date(new Date().getFullYear(), new Date().getMonth(), 5).getTime() - 1000 * 60 * 60 * 24 * 5, ownerName: 'Pedro', ownerLastName: 'Rodríguez', ownerDNI: '11223344C', ownerPhone: '5511223344', ownerEmail: 'pedro.rodriguez@example.com', address: 'Boulevard de los Sueños 500', mapLocation: 'https://maps.google.com/?q=Boulevard+de+los+Sueños+500' },
  ],
  users: [
    { id: 1, username: 'admin', password: 'password', role: 'admin', marketId: 'market1', accessBlocked: false, lastActive: Date.now() - 1000 * 60 * 10, permissions: { ventas: { ver: true, editar: true, eliminar: true }, reportes: { ver: true, editar: true, eliminar: true }, pagos: { ver: true, editar: true, eliminar: true }, stock: { ver: true, editar: true, eliminar: true }, configuracion: { ver: true, editar: true, eliminar: true } } },
    { id: 2, username: 'vendedor1', password: 'pass', role: 'vendedor', marketId: 'market1', accessBlocked: false, lastActive: Date.now() - 1000 * 60 * 30, permissions: { ventas: { ver: true, editar: true, eliminar: false }, reportes: { ver: false, editar: false, eliminar: false }, pagos: { ver: false, editar: false, eliminar: false }, stock: { ver: true, editar: false, eliminar: false }, configuracion: { ver: false, editar: false, eliminar: false } } },
    { id: 3, username: 'vendedor2', password: 'pass', role: 'vendedor', marketId: 'market2', accessBlocked: true, lastActive: Date.now() - 1000 * 60 * 60 * 2, permissions: { ventas: { ver: true, editar: true, eliminar: false }, reportes: { ver: false, editar: false, eliminar: false }, pagos: { ver: false, editar: false, eliminar: false }, stock: { ver: true, editar: false, eliminar: false }, configuracion: { ver: false, editar: false, eliminar: false } } },
    { id: 4, username: 'marketOwner1', password: 'pass', role: 'market', marketId: 'market1', accessBlocked: false, lastActive: Date.now() - 1000 * 60 * 60 * 1, permissions: { ventas: { ver: true, editar: true, eliminar: true }, reportes: { ver: true, editar: true, eliminar: true }, pagos: { ver: true, editar: true, eliminar: true }, stock: { ver: true, editar: true, eliminar: true }, configuracion: { ver: true, editar: true, eliminar: true } } },
    { id: 5, username: 'vendedor3', password: 'pass', role: 'vendedor', marketId: 'market1', accessBlocked: false, lastActive: Date.now() - 1000 * 60 * 45, permissions: { ventas: { ver: true, editar: true, eliminar: false }, reportes: { ver: false, editar: false, eliminar: false }, pagos: { ver: false, editar: false, eliminar: false }, stock: { ver: true, editar: false, eliminar: false }, configuracion: { ver: false, editar: false, eliminar: false } } },
    { id: 6, username: 'vendedor4', password: 'pass', role: 'vendedor', marketId: 'market2', accessBlocked: false, lastActive: Date.now() - 1000 * 60 * 60 * 3, permissions: { ventas: { ver: true, editar: true, eliminar: false }, reportes: { ver: false, editar: false, eliminar: false }, pagos: { ver: false, editar: false, eliminar: false }, stock: { ver: true, editar: false, eliminar: false }, configuracion: { ver: false, editar: false, eliminar: false } } },
    { id: 7, username: 'vendedor5', password: 'pass', role: 'vendedor', marketId: 'market3', accessBlocked: true, lastActive: Date.now() - 1000 * 60 * 60 * 24 * 6, permissions: { ventas: { ver: true, editar: true, eliminar: false }, reportes: { ver: false, editar: false, eliminar: false }, pagos: { ver: false, editar: false, eliminar: false }, stock: { ver: true, editar: false, eliminar: false }, configuracion: { ver: false, editar: false, eliminar: false } } },
  ],
  transactions: [
    { id: 'trans1', date: Date.now() - 1000 * 60 * 60 * 24 * 35, marketId: 'market1', operationNumber: 'OP12345', amount: 100.00 },
    { id: 'trans2', date: Date.now() - 1000 * 60 * 60 * 24 * 65, marketId: 'market2', operationNumber: 'OP67890', amount: 120.00 },
    { id: 'trans3', date: Date.now() - 1000 * 60 * 60 * 24 * 5, marketId: 'market1', operationNumber: 'OP54321', amount: 100.00 },
    { id: 'trans4', date: Date.now() - 1000 * 60 * 60 * 24 * 10, marketId: 'market3', operationNumber: 'OP98765', amount: 90.00 },
  ],
  permissionSections: ['ventas', 'reportes', 'pagos', 'stock', 'configuracion'], // Secciones de permisos configurables
  roles: { // Roles predefinidos con sus permisos
    dueño: {
      ventas: { ver: true, editar: true, eliminar: true },
      reportes: { ver: true, editar: true, eliminar: true },
      pagos: { ver: true, editar: true, eliminar: true },
      stock: { ver: true, editar: true, eliminar: true },
      configuracion: { ver: true, editar: true, eliminar: true }
    },
    encargado: {
      ventas: { ver: true, editar: true, eliminar: false },
      reportes: { ver: true, editar: false, eliminar: false },
      pagos: { ver: false, editar: false, eliminar: false },
      stock: { ver: true, editar: true, eliminar: false },
      configuracion: { ver: false, editar: false, eliminar: false }
    },
    vendedor: {
      ventas: { ver: true, editar: true, eliminar: false },
      reportes: { ver: false, editar: false, eliminar: false },
      pagos: { ver: false, editar: false, eliminar: false },
      stock: { ver: true, editar: false, eliminar: false },
      configuracion: { ver: false, editar: false, eliminar: false }
    },
  },
  settings: { // Mock de configuración general
    logoUrl: 'https://via.placeholder.com/150/000000/FFFFFF?text=Logo',
    backgroundUrl: 'https://via.placeholder.com/1200x800/CCCCCC/333333?text=Fondo',
    commerceName: 'Mi Comercio',
    openingHours: { // Horarios de apertura por defecto
      monday: [{ start: '09:00', end: '18:00' }],
      tuesday: [{ start: '09:00', end: '18:00' }],
      wednesday: [{ start: '09:00', end: '18:00' }],
      thursday: [{ start: '09:00', end: '18:00' }],
      friday: [{ start: '09:00', end: '18:00' }],
      saturday: [{ start: '10:00', end: '14:00' }],
      sunday: [], // Cerrado
    },
    language: 'es' // Nuevo campo para el idioma
  },
  subscriptionPlans: [
    { id: 'plan1', name: 'Básico', price: 50.00, features: ['Ventas', 'Reportes Básicos'], maxUsers: 5 },
    { id: 'plan2', name: 'Premium', price: 100.00, features: ['Ventas', 'Reportes Avanzados', 'Pagos'], maxUsers: 10 },
  ]
};