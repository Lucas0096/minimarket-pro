import React from 'react';

const AdminAddUser = ({
  editingUser, setEditingUser,
  newUsername, setNewUsername,
  newPassword, setNewPassword,
  newUserRole, setNewUserRole,
  selectedMarketForUser, setSelectedMarketForUser,
  markets, roles,
  handleAddUser, handleUpdateUser, handleCancelEdit, setCurrentView
}) => {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700 max-w-md mx-auto">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">
        {editingUser ? 'Editar Usuario' : 'Crear Nuevo Usuario'}
      </h3>
      <div className="space-y-3">
        <select
          value={editingUser?.marketId || selectedMarketForUser}
          onChange={(e) =>
            editingUser
              ? setEditingUser({ ...editingUser, marketId: e.target.value })
              : setSelectedMarketForUser(e.target.value)
          }
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        >
          <option value="">Seleccionar mercado</option>
          {markets.map(market => (
            <option key={market.id} value={market.id}>{market.name}</option>
          ))}
        </select>
        <input
          type="text"
          value={editingUser?.username || newUsername}
          onChange={(e) =>
            editingUser
              ? setEditingUser({ ...editingUser, username: e.target.value })
              : setNewUsername(e.target.value)
          }
          placeholder="Nombre de usuario"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          disabled={!!editingUser}
        />
        <input
          type="password"
          value={editingUser?.password || newPassword}
          onChange={(e) =>
            editingUser
              ? setEditingUser({ ...editingUser, password: e.target.value })
              : setNewPassword(e.target.value)
          }
          placeholder="Contraseña"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <select
          value={editingUser?.role || newUserRole}
          onChange={(e) =>
            editingUser
              ? setEditingUser({ ...editingUser, role: e.target.value })
              : setNewUserRole(e.target.value)
          }
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        >
          {Object.keys(roles).map(roleKey => (
            <option key={roleKey} value={roleKey}>{roleKey.charAt(0).toUpperCase() + roleKey.slice(1)}</option>
          ))}
        </select>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          <button
            onClick={editingUser ? handleUpdateUser : handleAddUser}
            className="flex-1 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
          >
            {editingUser ? 'Actualizar' : 'Crear'}
          </button>
          <button
            type="button"
            onClick={() => {
              handleCancelEdit();
              setCurrentView('users');
            }}
            className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminAddUser;

// DONE