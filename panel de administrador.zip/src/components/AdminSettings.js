import React from 'react';

const AdminSettings = ({
  settings,
  handleSettingsChange,
  handleImageUpload,
  handleOpeningHoursChange,
  addTimeSlot,
  removeTimeSlot,
  setCurrentView
}) => {
  const weekDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
  const weekendDays = ['saturday', 'sunday'];
  const dayNames = {
    monday: 'Lunes', tuesday: 'Martes', wednesday: 'Miércoles', thursday: 'Jueves',
    friday: 'Viernes', saturday: 'Sábado', sunday: 'Domingo'
  };

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Español' },
    { code: 'pt', name: 'Português' },
    { code: 'it', name: 'Italiano' },
    { code: 'de', name: 'Alemán' },
  ];

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700 max-w-md mx-auto">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Configuración General</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>
      <div className="flex flex-col space-y-4">
        <div>
          <label htmlFor="logoUpload" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subir Logo</label>
          <input
            type="file"
            id="logoUpload"
            accept="image/*"
            onChange={(e) => handleImageUpload(e, 'logoUrl')}
            className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          {settings.logoUrl && <img src={settings.logoUrl} alt="Logo Preview" className="mt-2 h-20 w-auto object-contain" />}
        </div>
        <div>
          <label htmlFor="backgroundUpload" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subir Imagen de Fondo</label>
          <input
            type="file"
            id="backgroundUpload"
            accept="image/*"
            onChange={(e) => handleImageUpload(e, 'backgroundUrl')}
            className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          {settings.backgroundUrl && <img src={settings.backgroundUrl} alt="Background Preview" className="mt-2 w-full h-32 object-cover rounded-lg" />}
        </div>
        <div>
          <label htmlFor="commerceName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Nombre del Comercio</label>
          <input
            type="text"
            id="commerceName"
            value={settings.commerceName || ''}
            onChange={(e) => handleSettingsChange('commerceName', e.target.value)}
            placeholder="Nombre del comercio"
            className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
        </div>

        {/* Apartado de Idiomas */}
        <div className="mt-4">
          <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Idioma</h4>
          <select
            id="language"
            value={settings.language || 'es'}
            onChange={(e) => handleSettingsChange('language', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          >
            {languages.map(lang => (
              <option key={lang.code} value={lang.code}>{lang.name}</option>
            ))}
          </select>
        </div>

        {/* Horarios de Apertura */}
        <div className="mt-4">
          <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Horarios de Apertura</h4>
          
          {/* Días de semana (Lunes a Viernes) */}
          <div className="mb-4 p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
            <h5 className="font-medium text-gray-800 dark:text-white mb-2">Lunes a Viernes</h5>
            {weekDays.map(day => (
              <div key={day} className="flex items-center justify-between mb-2">
                <span className="text-gray-700 dark:text-gray-300 w-20">{dayNames[day]}:</span>
                <div className="flex-1 flex flex-wrap gap-2">
                  {(settings.openingHours[day] || []).map((slot, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <input
                        type="time"
                        value={slot.start}
                        onChange={(e) => handleOpeningHoursChange(day, index, 'start', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white w-24"
                      />
                      <span>-</span>
                      <input
                        type="time"
                        value={slot.end}
                        onChange={(e) => handleOpeningHoursChange(day, index, 'end', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white w-24"
                      />
                      <button
                        onClick={() => removeTimeSlot(day, index)}
                        className="px-2 py-1 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => addTimeSlot(day)}
                    className="px-3 py-1 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Fin de semana (Sábado y Domingo) */}
          <div className="mb-4 p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
            <h5 className="font-medium text-gray-800 dark:text-white mb-2">Sábado y Domingo</h5>
            {weekendDays.map(day => (
              <div key={day} className="flex items-center justify-between mb-2">
                <span className="text-gray-700 dark:text-gray-300 w-20">{dayNames[day]}:</span>
                <div className="flex-1 flex flex-wrap gap-2">
                  {(settings.openingHours[day] || []).map((slot, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <input
                        type="time"
                        value={slot.start}
                        onChange={(e) => handleOpeningHoursChange(day, index, 'start', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white w-24"
                      />
                      <span>-</span>
                      <input
                        type="time"
                        value={slot.end}
                        onChange={(e) => handleOpeningHoursChange(day, index, 'end', e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white w-24"
                      />
                      <button
                        onClick={() => removeTimeSlot(day, index)}
                        className="px-2 py-1 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition-colors"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                  <button
                    onClick={() => addTimeSlot(day)}
                    className="px-3 py-1 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;