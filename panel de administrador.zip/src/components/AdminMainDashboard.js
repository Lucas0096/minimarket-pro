import React from 'react';

const AdminMainDashboard = ({ setCurrentView }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <button
        onClick={() => setCurrentView('users')}
        className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
      >
        <span className="text-2xl font-bold">Mercados y Usuarios</span>
        <span className="text-sm mt-2">Ver y gestionar usuarios existentes</span>
      </button>
      <button
        onClick={() => setCurrentView('payments')}
        className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
      >
        <span className="text-2xl font-bold">Pagos</span>
        <span className="text-sm mt-2">Gestionar estados de pago de mercados</span>
      </button>
      <button
        onClick={() => setCurrentView('permissions')}
        className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
      >
        <span className="text-2xl font-bold">Permisos y Roles Avanzados</span>
        <span className="text-sm mt-2">Configurar accesos y roles de usuario</span>
      </button>
      <button
        onClick={() => setCurrentView('settings')}
        className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
      >
        <span className="text-2xl font-bold">Configuración General</span>
        <span className="text-sm mt-2">Personalizar el sistema</span>
      </button>
    </div>
  );
};

export default AdminMainDashboard;