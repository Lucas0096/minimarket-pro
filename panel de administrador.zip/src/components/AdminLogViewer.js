import React, { useState, useEffect } from 'react';
import { getAllData } from '../utils/dataHandlers';

const AdminLogViewer = ({ setCurrentView, markets, users }) => {
  const [logs, setLogs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadLogs = async () => {
      const loadedLogs = await getAllData('logs');
      setLogs(loadedLogs);
    };
    loadLogs();
  }, []);

  const getMarketName = (marketId) => {
    const market = markets.find(m => m.id === marketId);
    return market ? market.name : 'N/A';
  };

  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId || u.username === userId); // Puede ser ID o username
    return user ? user.username : 'N/A';
  };

  const filteredLogs = logs.filter(log => {
    const logDate = new Date(log.date).toLocaleDateString();
    const marketName = getMarketName(log.marketId);
    const userName = getUserName(log.userId);

    return (
      logDate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.activity.toLowerCase().includes(searchTerm.toLowerCase()) ||
      marketName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Registro de Actividad (Log)</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Buscar en el log..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
          <thead className="bg-gray-100 dark:bg-gray-600">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Fecha</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Actividad</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Mercado</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Usuario</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
            {filteredLogs.map(log => (
              <tr key={log.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {new Date(log.date).toLocaleString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">{log.activity}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">{getMarketName(log.marketId)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">{getUserName(log.userId)}</div>
                </td>
              </tr>
            ))}
            {filteredLogs.length === 0 && (
              <tr>
                <td colSpan="4" className="px-6 py-4 text-center text-gray-500 dark:text-gray-300">
                  No se encontraron registros de actividad.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminLogViewer;