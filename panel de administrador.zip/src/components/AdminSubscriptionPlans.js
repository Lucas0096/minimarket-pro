import React from 'react';

const AdminSubscriptionPlans = ({
  subscriptionPlans,
  newPlanName, setNewPlanName,
  newPlanPrice, setNewPlanPrice,
  newPlanFeatures, setNewPlanFeatures,
  newPlanMaxUsers, setNewPlanMaxUsers,
  handleAddSubscriptionPlan,
  handleDeleteSubscriptionPlan
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-6">
      <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Gestión de Planes de Suscripción</h4>
      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg shadow-sm mb-4">
        <h5 className="text-md font-semibold text-gray-800 dark:text-white mb-3">Agregar Nuevo Plan</h5>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            value={newPlanName}
            onChange={(e) => setNewPlanName(e.target.value)}
            placeholder="Nombre del Plan (ej. Básico)"
            className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          <input
            type="number"
            value={newPlanPrice}
            onChange={(e) => setNewPlanPrice(e.target.value)}
            placeholder="Precio (ej. 50.00)"
            className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          <input
            type="text"
            value={newPlanFeatures}
            onChange={(e) => setNewPlanFeatures(e.target.value)}
            placeholder="Características (separadas por coma, ej. Ventas, Reportes)"
            className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          <input
            type="number"
            value={newPlanMaxUsers}
            onChange={(e) => setNewPlanMaxUsers(e.target.value)}
            placeholder="Máx. Usuarios (ej. 5)"
            className="px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
        </div>
        <button
          onClick={handleAddSubscriptionPlan}
          className="w-full mt-4 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
        >
          Agregar Plan
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
          <thead className="bg-gray-100 dark:bg-gray-600">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Nombre</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Precio</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Características</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Máx. Usuarios</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
            {subscriptionPlans.map(plan => (
              <tr key={plan.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">{plan.name}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">${plan.price.toFixed(2)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">{plan.features.join(', ')}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">{plan.maxUsers}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => handleDeleteSubscriptionPlan(plan.id)}
                    className="text-red-600 hover:text-red-800 transition-colors"
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminSubscriptionPlans;