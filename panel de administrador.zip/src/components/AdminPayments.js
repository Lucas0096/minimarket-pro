import React, { useState } from 'react';
import { getRemainingTime, calculateSubscriptionEndDate } from '../utils/timeFormatters';

const AdminPayments = ({
  markets, transactions,
  setCurrentView,
  handleMarketAction,
  setMessage,
  putData,
  syncLocalStorageWithIndexedDB
}) => {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [hoveredDayInfo, setHoveredDayInfo] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

  const getDaysInMonth = (month, year) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (month, year) => new Date(year, month, 1).getDay();

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear);
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear);
    const calendarDays = [];

    for (let i = 0; i < firstDay; i++) {
      calendarDays.push(<div key={`empty-${i}`} className="p-2 text-center text-gray-400"></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentYear, currentMonth, day);
      const isToday = date.toDateString() === new Date().toDateString();
      const isPaymentPeriod = day >= 1 && day <= 5;

      const blockingMarkets = markets.filter(market => {
        const endDate = new Date(market.subscriptionEndDate);
        return endDate.getDate() === day && endDate.getMonth() === currentMonth && endDate.getFullYear() === currentYear;
      });
      const isBlockingDay = blockingMarkets.length > 0;

      calendarDays.push(
        <div
          key={day}
          className={`relative p-2 text-center rounded-lg
            ${isToday ? 'bg-blue-200 text-blue-800 font-bold' : 'bg-gray-100 dark:bg-gray-600 text-gray-800 dark:text-white'}
            ${isPaymentPeriod ? 'bg-green-100 text-green-800 font-bold border-2 border-green-500' : ''}
            ${isBlockingDay ? 'bg-red-100 text-red-800 font-bold border-2 border-red-500' : ''}
          `}
          onMouseEnter={() => {
            if (isBlockingDay) {
              setHoveredDayInfo({ day, markets: blockingMarkets.map(m => m.name) });
            }
          }}
          onMouseLeave={() => setHoveredDayInfo(null)}
        >
          {day}
          {hoveredDayInfo && hoveredDayInfo.day === day && (
            <div className="absolute z-10 bg-gray-800 text-white text-xs p-2 rounded-md shadow-lg -mt-10 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
              Mercados que se bloquean:
              {hoveredDayInfo.markets.map((name, index) => (
                <div key={index}>{name}</div>
              ))}
            </div>
          )}
        </div>
      );
    }
    return calendarDays;
  };

  const goToPreviousMonth = () => {
    setCurrentMonth(prevMonth => {
      if (prevMonth === 0) {
        setCurrentYear(prevYear => prevYear - 1);
        return 11;
      }
      return prevMonth - 1;
    });
  };

  const goToNextMonth = () => {
    setCurrentMonth(prevMonth => {
      if (prevMonth === 11) {
        setCurrentYear(prevYear => prevYear + 1);
        return 0;
      }
      return prevMonth + 1;
    });
  };

  const sendReminder = (market, type, daysBefore = null) => {
    let subject = `Recordatorio de Pago - ${market.name}`;
    let body = `Estimado ${market.ownerName} ${market.ownerLastName},\n\n`;
    const remaining = getRemainingTime(market.subscriptionEndDate);
    const isBlocked = remaining.text === 'Bloqueado';

    if (isBlocked) {
      body += `Su suscripción para el mercado "${market.name}" ha vencido. Su acceso ha sido bloqueado.\n`;
      body += `Por favor, realice el pago para reactivar su servicio. Puede haber recargos aplicables.\n\n`;
      subject = `URGENTE: Suscripción Vencida - ${market.name}`;
    } else if (daysBefore === 7) {
      body += `Le recordamos que su suscripción para el mercado "${market.name}" vencerá en ${remaining.days} días.\n`;
      body += `Por favor, realice el pago a tiempo para evitar interrupciones en el servicio.\n\n`;
    } else if (daysBefore === 1) {
      body += `¡Último recordatorio! Su suscripción para el mercado "${market.name}" vencerá en menos de 24 horas.\n`;
      body += `Asegúrese de realizar el pago para mantener su servicio activo.\n\n`;
    } else {
      body += `Este es un recordatorio general sobre su suscripción para el mercado "${market.name}".\n`;
      body += `Días restantes: ${remaining.text}.\n\n`;
    }

    body += `Gracias por su atención.\n\nAtentamente,\nEl equipo de Administración.`;

    if (type === 'email') {
      window.open(`mailto:${market.ownerEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
      setMessage({ type: 'success', text: `Recordatorio por correo enviado a ${market.ownerName} (${market.ownerEmail}).` });
    } else if (type === 'whatsapp') {
      const whatsappUrl = `https://wa.me/${market.ownerPhone}?text=${encodeURIComponent(body)}`;
      window.open(whatsappUrl, '_blank');
      setMessage({ type: 'success', text: `Recordatorio por WhatsApp enviado a ${market.ownerName} (${market.ownerPhone}).` });
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const market = markets.find(m => m.id === transaction.marketId);
    const ownerName = market ? `${market.ownerName} ${market.ownerLastName}` : '';
    const marketName = market ? market.name : '';
    const transactionDate = new Date(transaction.date).toLocaleDateString();

    return (
      transactionDate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      marketName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.operationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.amount.toString().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Gestión de Pagos de Mercados</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-6">
        <div className="flex justify-between items-center mb-4">
          <button onClick={goToPreviousMonth} className="px-3 py-1 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">
            &lt;
          </button>
          <h4 className="text-lg font-semibold text-gray-800 dark:text-white">
            {monthNames[currentMonth]} {currentYear}
          </h4>
          <button onClick={goToNextMonth} className="px-3 py-1 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">
            &gt;
          </button>
        </div>
        <div className="grid grid-cols-7 gap-2 text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
          <div className="text-center">Dom</div>
          <div className="text-center">Lun</div>
          <div className="text-center">Mar</div>
          <div className="text-center">Mié</div>
          <div className="text-center">Jue</div>
          <div className="text-center">Vie</div>
          <div className="text-center">Sáb</div>
        </div>
        <div className="grid grid-cols-7 gap-2">
          {renderCalendar()}
        </div>
        <div className="mt-4 text-sm text-gray-700 dark:text-gray-300">
          <p><span className="inline-block w-4 h-4 bg-green-100 border-2 border-green-500 rounded-sm mr-2"></span>Días de pago (1 al 5)</p>
          <p><span className="inline-block w-4 h-4 bg-red-100 border-2 border-red-500 rounded-sm mr-2"></span>Días de bloqueo de suscripción</p>
          <p><span className="inline-block w-4 h-4 bg-blue-200 rounded-sm mr-2"></span>Día actual</p>
        </div>
      </div>

      <div className="overflow-x-auto mb-6">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
          <thead className="bg-gray-100 dark:bg-gray-600">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Mercado</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Días Restantes</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Horas Restantes</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Acciones de Recordatorio</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Acciones de Suscripción</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
            {markets.map(market => {
              const remaining = getRemainingTime(market.subscriptionEndDate);
              const isBlocked = remaining.text === 'Bloqueado';

              return (
                <tr key={market.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{market.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${remaining.color}`}>
                      {remaining.days}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${remaining.color}`}>
                      {remaining.hours}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => sendReminder(market, 'email', 7)}
                        className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 transition-colors"
                      >
                        Email (7 días)
                      </button>
                      <button
                        onClick={() => sendReminder(market, 'whatsapp', 7)}
                        className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-md hover:bg-green-200 transition-colors"
                      >
                        WhatsApp (7 días)
                      </button>
                      <button
                        onClick={() => sendReminder(market, 'email', 1)}
                        className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 transition-colors"
                      >
                        Email (24 hs)
                      </button>
                      <button
                        onClick={() => sendReminder(market, 'whatsapp', 1)}
                        className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-md hover:bg-green-200 transition-colors"
                      >
                        WhatsApp (24 hs)
                      </button>
                      {isBlocked && (
                        <>
                          <button
                            onClick={() => sendReminder(market, 'email', null)}
                            className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
                          >
                            Email (Recargo)
                          </button>
                          <button
                            onClick={() => sendReminder(market, 'whatsapp', null)}
                            className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
                          >
                            WhatsApp (Recargo)
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex flex-wrap gap-2">
                      <button
                        onClick={() => handleMarketAction(market.id, 'extendDays', 30)}
                        className="px-2 py-1 text-xs bg-purple-100 text-purple-800 rounded-md hover:bg-purple-200 transition-colors"
                      >
                        Sumar 30 Días
                      </button>
                      {isBlocked ? (
                        <button
                          onClick={() => handleMarketAction(market.id, 'unblockAccess')}
                          className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-md hover:bg-green-200 transition-colors"
                        >
                          Desbloquear
                        </button>
                      ) : (
                        <button
                          onClick={() => handleMarketAction(market.id, 'blockAccess')}
                          className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
                        >
                          Bloquear
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminPayments;