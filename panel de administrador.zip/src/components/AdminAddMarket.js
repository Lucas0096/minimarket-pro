import React from 'react';

const AdminAddMarket = ({
  newMarketName, setNewMarketName,
  newMarketOwnerName, setNewMarketOwnerName,
  newMarketOwnerLastName, setNewMarketOwnerLastName,
  newMarketOwnerDNI, setNewMarketOwnerDNI,
  newMarketOwnerPhone, setNewMarketOwnerPhone,
  newMarketOwnerEmail, setNewMarketOwnerEmail,
  newMarketAddress, setNewMarketAddress,
  newMarketMapLocation, setNewMarketMapLocation,
  handleAddMarket, setCurrentView
}) => {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700 max-w-md mx-auto">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Crear Nuevo Mercado</h3>
      <div className="flex flex-col space-y-4">
        <input
          type="text"
          value={newMarketName}
          onChange={(e) => setNewMarketName(e.target.value)}
          placeholder="Nombre del Mercado"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="text"
          value={newMarketOwnerName}
          onChange={(e) => setNewMarketOwnerName(e.target.value)}
          placeholder="Nombre del Dueño"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="text"
          value={newMarketOwnerLastName}
          onChange={(e) => setNewMarketOwnerLastName(e.target.value)}
          placeholder="Apellido del Dueño"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="text"
          value={newMarketOwnerDNI}
          onChange={(e) => setNewMarketOwnerDNI(e.target.value)}
          placeholder="DNI del Dueño"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="tel"
          value={newMarketOwnerPhone}
          onChange={(e) => setNewMarketOwnerPhone(e.target.value)}
          placeholder="Teléfono del Dueño"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="email"
          value={newMarketOwnerEmail}
          onChange={(e) => setNewMarketOwnerEmail(e.target.value)}
          placeholder="Correo del Dueño"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="text"
          value={newMarketAddress}
          onChange={(e) => setNewMarketAddress(e.target.value)}
          placeholder="Dirección del Mercado"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <input
          type="url"
          value={newMarketMapLocation}
          onChange={(e) => setNewMarketMapLocation(e.target.value)}
          placeholder="Ubicación de Maps (URL)"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        <button
          onClick={handleAddMarket}
          className="w-full px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
        >
          Agregar Mercado
        </button>
        <button
          onClick={() => setCurrentView('main')}
          className="w-full px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
        >
          Volver
        </button>
      </div>
    </div>
  );
};

export default AdminAddMarket;