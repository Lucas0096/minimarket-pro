import React from 'react';
import { getTimeDifference, getRemainingTime } from '../utils/timeFormatters';

const AdminUsersList = ({
  markets, users,
  setCurrentView,
  setEditingUser, resetUserForm, setSelectedMarketForUser,
  handleEditUser, handleDeleteUser
}) => {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Mercados y Usuarios</h3>
      <div className="flex justify-between items-center mb-4">
        <button
          onClick={() => setCurrentView('main')}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
        >
          Volver al Menú Principal
        </button>
        <button
          onClick={() => {
            setEditingUser(null);
            resetUserForm();
            setSelectedMarketForUser('');
            setCurrentView('addMarket');
          }}
          className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
        >
          Agregar Mercado
        </button>
      </div>
      <div className="overflow-x-auto">
        {markets.map(market => {
          const marketUsers = users.filter(u => u.marketId === market.id && u.role !== 'admin');
          const marketSubscriptionStatus = getRemainingTime(market.subscriptionEndDate);

          return (
            <div key={market.id} className="mb-6 p-4 border border-gray-200 dark:border-gray-600 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Mercado: {market.name}
                  <span className={`ml-2 text-sm ${marketSubscriptionStatus.color}`}>
                    ({marketSubscriptionStatus.text})
                  </span>
                </h4>
                <button
                  onClick={() => {
                    setEditingUser(null);
                    resetUserForm();
                    setSelectedMarketForUser(market.id);
                    setCurrentView('addUser');
                  }}
                  className="px-3 py-1 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
                >
                  + Agregar Usuario
                </button>
              </div>
              {marketUsers.length > 0 ? (
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
                  <thead className="bg-gray-100 dark:bg-gray-600">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Usuario</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Rol</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Estado</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Última Actividad</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider dark:text-gray-300">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                    {marketUsers.map(user => (
                      <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">{user.username}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 dark:text-white">{user.role}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            (Date.now() - user.lastActive) < (1000 * 60 * 60) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {(Date.now() - user.lastActive) < (1000 * 60 * 60) ? 'Online' : 'Offline'}
                          </span>
                          {marketSubscriptionStatus.text === 'Bloqueado' && (
                            <span className="ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                              Bloqueado
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 dark:text-white">{getTimeDifference(user.lastActive)} sin conexión</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => handleEditUser(user)}
                              className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 transition-colors"
                            >
                              Editar
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteUser(user.id)}
                              className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
                            >
                              Eliminar
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="text-gray-500 dark:text-gray-300">No hay usuarios en este mercado.</p>
              )}
            </div>
          );
        })}
        {markets.length === 0 && (
          <p className="text-gray-500 dark:text-gray-300">No hay mercados registrados.</p>
        )}
      </div>
    </div>
  );
};

export default AdminUsersList;