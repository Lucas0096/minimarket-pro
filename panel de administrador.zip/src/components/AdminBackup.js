import React, { useState, useEffect } from 'react';
import { getAllData } from '../utils/dataHandlers';

const AdminBackup = ({ setCurrentView, setMessage }) => {
  const [lastBackupTime, setLastBackupTime] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [restoreMessage, setRestoreMessage] = useState({ type: '', text: '' });

  // Función para generar el backup
  const generateBackup = async () => {
    try {
      const allMarkets = await getAllData('markets');
      const allUsers = await getAllData('users');
      const allTransactions = await getAllData('transactions');
      const allPermissionSections = await getAllData('permissionSections');
      const allSettings = await getAllData('settings'); // Asumiendo que settings también se puede obtener así
      const allSubscriptionPlans = await getAllData('subscriptionPlans');
      const allRoles = await getAllData('roles'); // Asumiendo que roles también se puede obtener así
      const allLogs = await getAllData('logs');

      const backupData = {
        markets: allMarkets,
        users: allUsers,
        transactions: allTransactions,
        permissionSections: allPermissionSections,
        settings: allSettings,
        subscriptionPlans: allSubscriptionPlans,
        roles: allRoles,
        logs: allLogs,
        timestamp: Date.now()
      };

      const backupJson = JSON.stringify(backupData, null, 2);
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_mercado_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setLastBackupTime(Date.now());
      localStorage.setItem('lastBackupTime', Date.now());
      setMessage({ type: 'success', text: 'Backup generado con éxito.' });
    } catch (error) {
      console.error('Error al generar el backup:', error);
      setMessage({ type: 'error', text: 'Error al generar el backup.' });
    }
  };

  // Función para manejar la selección de archivo de restauración
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    setRestoreMessage({ type: '', text: '' }); // Limpiar mensaje al seleccionar nuevo archivo
  };

  // Función para restaurar desde un backup
  const handleRestore = () => {
    if (!selectedFile) {
      setRestoreMessage({ type: 'error', text: 'Por favor, selecciona un archivo de backup para restaurar.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const backupData = JSON.parse(e.target.result);

        // Aquí deberías implementar la lógica para restaurar los datos
        // Esto es un ejemplo simplificado y en un entorno real requeriría
        // una lógica más robusta para actualizar IndexedDB o tu backend.
        // Por ahora, solo mostramos un mensaje de éxito/error.

        // Ejemplo: Restaurar solo mercados (esto es muy simplificado)
        // await putData('markets', backupData.markets); // Esto no funcionaría directamente para un array
        // Necesitarías iterar y actualizar/agregar cada elemento.

        setRestoreMessage({ type: 'success', text: 'Archivo de backup cargado. La restauración de datos debe ser implementada.' });
        setMessage({ type: 'success', text: 'Archivo de backup cargado para restauración.' });
        setSelectedFile(null); // Limpiar el archivo seleccionado
      } catch (error) {
        console.error('Error al restaurar el backup:', error);
        setRestoreMessage({ type: 'error', text: `Error al procesar el archivo de backup: ${error.message}` });
      }
    };
    reader.readAsText(selectedFile);
  };

  useEffect(() => {
    const storedTime = localStorage.getItem('lastBackupTime');
    if (storedTime) {
      setLastBackupTime(parseInt(storedTime));
    }

    // Configurar el backup automático diario
    const setupDailyBackup = () => {
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(now.getDate() + 1);
      tomorrow.setHours(3, 0, 0, 0); // Por ejemplo, a las 3 AM

      const timeToNextBackup = tomorrow.getTime() - now.getTime();

      const timeoutId = setTimeout(() => {
        generateBackup();
        // Configurar el siguiente backup para el día siguiente
        setInterval(generateBackup, 24 * 60 * 60 * 1000);
      }, timeToNextBackup);

      return () => clearTimeout(timeoutId);
    };

    // Deshabilitado por ahora para evitar backups constantes en el entorno de desarrollo
    // setupDailyBackup(); 

  }, []);

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Gestión de Backups</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>

      {/* Sección de Generar Backup */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-6">
        <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Generar Copia de Seguridad</h4>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Genera una copia de seguridad completa de la configuración actual de tu mercado en formato JSON.
        </p>
        <button
          onClick={generateBackup}
          className="w-full px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
        >
          Generar Backup Ahora
        </button>
        {lastBackupTime && (
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 text-center">
            Último backup generado: {new Date(lastBackupTime).toLocaleString()}
          </p>
        )}
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 text-center">
          El backup automático diario está configurado para ejecutarse a las 3 AM.
          (Funcionalidad de backup automático deshabilitada en este entorno de demostración).
        </p>
      </div>

      {/* Sección de Restaurar Backup */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Restaurar Copia de Seguridad</h4>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Carga un archivo de backup JSON previamente descargado para restaurar la configuración de tu mercado.
        </p>
        
        {restoreMessage.text && (
          <div className={`p-3 mb-4 rounded-md ${restoreMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {restoreMessage.text}
          </div>
        )}

        <label htmlFor="backupFile" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Selecciona un archivo de backup (.json)
        </label>
        <input
          type="file"
          id="backupFile"
          accept=".json"
          onChange={handleFileChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        
        <button
          onClick={handleRestore}
          disabled={!selectedFile}
          className={`w-full mt-4 px-4 py-2 rounded-lg transition-colors ${
            selectedFile ? 'bg-black text-white hover:bg-gray-800' : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Restaurar desde Backup
        </button>
      </div>
    </div>
  );
};

export default AdminBackup;