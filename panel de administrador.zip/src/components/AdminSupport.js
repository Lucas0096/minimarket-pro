import React, { useState } from 'react';

const AdminSupport = ({ setCurrentView }) => {
  const [selectedProblem, setSelectedProblem] = useState(null);
  const [customProblem, setCustomProblem] = useState('');

  const problemOptions = [
    { id: 'venta', text: 'Carga de Venta' },
    { id: 'stock', text: 'Stock' }, // Cambiado de 'Nueva Stock' a 'Stock'
    { id: 'ventasWeb', text: 'Ventas WEB' },
    { id: 'calculadora', text: 'Carga de Calculadora' },
    { id: 'cuentaCorriente', text: 'Nueva Cuenta Corriente' },
  ];

  const handleProblemSelection = (id) => {
    setSelectedProblem(id);
    setCustomProblem(''); // Limpiar problema personalizado si selecciona una opción predefinida
  };

  const handleContact = (type) => {
    let message = `Problema: `;
    if (selectedProblem === 'other') {
      message += `Otro - ${customProblem}`;
    } else if (selectedProblem) {
      const problemText = problemOptions.find(opt => opt.id === selectedProblem)?.text;
      message += problemText;
    } else {
      message = 'No se ha seleccionado ningún problema.';
    }

    if (type === 'whatsapp') {
      const whatsappNumber = '5491151501179'; // Número de WhatsApp actualizado
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    } else if (type === 'email') {
      const emailAddress = 'lucasbruseghini5@gmail.com'; // Correo electrónico actualizado
      const emailSubject = encodeURIComponent('Problema con el sistema');
      const emailBody = encodeURIComponent(message);
      window.open(`mailto:${emailAddress}?subject=${emailSubject}&body=${emailBody}`);
    }
  };

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700 max-w-2xl mx-auto">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Soporte y Ayuda</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Por favor, selecciona el tipo de problema que estás experimentando o descríbelo brevemente antes de contactarnos:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
          {problemOptions.map(option => (
            <button
              key={option.id}
              onClick={() => handleProblemSelection(option.id)}
              className={`px-4 py-3 rounded-lg transition-colors text-left ${
                selectedProblem === option.id
                  ? 'bg-black text-white shadow-lg'
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500'
              }`}
            >
              {option.text}
            </button>
          ))}
          <button
            onClick={() => handleProblemSelection('other')}
            className={`px-4 py-3 rounded-lg transition-colors text-left ${
              selectedProblem === 'other'
                ? 'bg-black text-white shadow-lg'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500'
            }`}
          >
            Otro problema (especificar)
          </button>
        </div>

        {selectedProblem === 'other' && (
          <div className="mb-6">
            <label htmlFor="customProblem" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Describe tu problema:
            </label>
            <textarea
              id="customProblem"
              rows="4"
              value={customProblem}
              onChange={(e) => setCustomProblem(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white resize-none"
              placeholder="Ej: No puedo iniciar sesión, la aplicación se cierra inesperadamente, etc."
            ></textarea>
          </div>
        )}

        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <button
            onClick={() => handleContact('whatsapp')}
            disabled={!selectedProblem || (selectedProblem === 'other' && !customProblem.trim())}
            className={`flex-1 px-4 py-3 rounded-lg transition-colors ${
              (selectedProblem && (selectedProblem !== 'other' || customProblem.trim()))
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Contactar por WhatsApp
          </button>
          <button
            onClick={() => handleContact('email')}
            disabled={!selectedProblem || (selectedProblem === 'other' && !customProblem.trim())}
            className={`flex-1 px-4 py-3 rounded-lg transition-colors ${
              (selectedProblem && (selectedProblem !== 'other' || customProblem.trim()))
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Contactar por Email
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSupport;