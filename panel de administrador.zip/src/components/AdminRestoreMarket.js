import React, { useState } from 'react';
import { putData, addData } from '../utils/dataHandlers'; // Asegúrate de que estas funciones existan y manejen la persistencia

const AdminRestoreMarket = ({ setCurrentView, markets, setMarkets, setMessage }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [restoreMessage, setRestoreMessage] = useState({ type: '', text: '' });

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
    setRestoreMessage({ type: '', text: '' }); // Limpiar mensaje al seleccionar nuevo archivo
  };

  const handleRestore = () => {
    if (!selectedFile) {
      setRestoreMessage({ type: 'error', text: 'Por favor, selecciona un archivo de backup.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const backupData = JSON.parse(e.target.result);

        if (!backupData || !backupData.market || !backupData.users) {
          setRestoreMessage({ type: 'error', text: 'El archivo de backup no tiene el formato correcto.' });
          return;
        }

        const { market: restoredMarket, users: restoredUsers } = backupData;

        // Verificar si el mercado ya existe
        const existingMarketIndex = markets.findIndex(m => m.id === restoredMarket.id);

        if (existingMarketIndex !== -1) {
          // Si el mercado existe, actualizarlo
          await putData('markets', restoredMarket);
          setMarkets(prevMarkets => prevMarkets.map(m => m.id === restoredMarket.id ? restoredMarket : m));
          setRestoreMessage({ type: 'success', text: `Mercado "${restoredMarket.name}" actualizado con éxito desde el backup.` });
        } else {
          // Si el mercado no existe, agregarlo
          await addData('markets', restoredMarket);
          setMarkets(prevMarkets => [...prevMarkets, restoredMarket]);
          setRestoreMessage({ type: 'success', text: `Mercado "${restoredMarket.name}" restaurado (agregado) con éxito desde el backup.` });
        }

        // Aquí deberías manejar la restauración de usuarios asociados al mercado
        // Esto es más complejo y requeriría lógica para:
        // 1. Eliminar usuarios antiguos del mercado restaurado (si aplica)
        // 2. Agregar o actualizar los usuarios del backup
        // Por simplicidad en este ejemplo, solo se muestra el concepto.
        // En un sistema real, necesitarías funciones putData/addData para 'users' también.
        setMessage({ type: 'success', text: `Mercado "${restoredMarket.name}" restaurado con éxito. Los usuarios asociados deben ser revisados manualmente.` });

        setSelectedFile(null); // Limpiar el archivo seleccionado
      } catch (error) {
        console.error('Error al restaurar el backup:', error);
        setRestoreMessage({ type: 'error', text: `Error al procesar el archivo de backup: ${error.message}` });
      }
    };
    reader.readAsText(selectedFile);
  };

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700 max-w-md mx-auto">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Restaurar Mercado desde Backup</h3>
      
      {restoreMessage.text && (
        <div className={`p-3 mb-4 rounded-md ${restoreMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          {restoreMessage.text}
        </div>
      )}

      <div className="flex flex-col space-y-4">
        <label htmlFor="backupFile" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Selecciona un archivo de backup (.json)
        </label>
        <input
          type="file"
          id="backupFile"
          accept=".json"
          onChange={handleFileChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
        />
        
        <button
          onClick={handleRestore}
          disabled={!selectedFile}
          className={`w-full px-4 py-2 rounded-lg transition-colors ${
            selectedFile ? 'bg-black text-white hover:bg-gray-800' : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          Restaurar Mercado
        </button>
        
        <button
          onClick={() => setCurrentView('main')}
          className="w-full px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
        >
          Volver
        </button>
      </div>
    </div>
  );
};

export default AdminRestoreMarket;