import React, { useState } from 'react';

const AdminPermissions = ({
  roles, setRoles,
  newRoleName, setNewRoleName,
  handleAddRole, handleUpdateRole, handleDeleteRole,
  editingRole, setEditingRole,
  setCurrentView,
  hasChanges, setHasChanges, handleSaveChanges
}) => {
  // Opciones de permisos granulares
  const permissionOptions = ['ver', 'editar', 'eliminar'];
  const [expandedRole, setExpandedRole] = useState(null); // Estado para controlar el rol expandido

  // Obtener las secciones de permisos de forma dinámica desde el primer rol si existe
  const permissionSections = Object.keys(roles).length > 0 ? Object.keys(Object.values(roles)[0]) : [];

  const handlePermissionChange = (roleKey, section, action) => {
    setRoles(prevRoles => {
      const updatedRoles = { ...prevRoles };
      updatedRoles[roleKey] = {
        ...updatedRoles[roleKey],
        [section]: {
          ...updatedRoles[roleKey][section],
          [action]: !updatedRoles[roleKey][section][action]
        }
      };
      return updatedRoles;
    });
    setHasChanges(true); // Indicar que hay cambios
  };

  const toggleRoleExpansion = (roleKey) => {
    setExpandedRole(expandedRole === roleKey ? null : roleKey);
  };

  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-sm dark:bg-gray-700">
      <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-4">Gestión de Roles</h3>
      <button
        onClick={() => setCurrentView('main')}
        className="mb-4 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
      >
        Volver al Menú Principal
      </button>

      <div className="mt-8 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
        <h4 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">Gestionar Roles</h4>
        <div className="flex space-x-2 mb-4">
          <input
            type="text"
            value={newRoleName}
            onChange={(e) => setNewRoleName(e.target.value)}
            placeholder="Nombre del nuevo rol"
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-black transition dark:bg-gray-600 dark:border-gray-500 dark:text-white"
          />
          <button
            onClick={editingRole ? handleUpdateRole : handleAddRole}
            className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
          >
            {editingRole ? 'Actualizar Rol' : 'Agregar Rol'}
          </button>
          {editingRole && (
            <button
              onClick={() => setEditingRole(null)}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500"
            >
              Cancelar Edición
            </button>
          )}
        </div>

        <div className="space-y-4">
          {Object.keys(roles).map(roleKey => (
            <div key={roleKey} className="bg-gray-100 dark:bg-gray-700 rounded-lg shadow-sm">
              <div
                className="flex justify-between items-center p-4 cursor-pointer"
                onClick={() => toggleRoleExpansion(roleKey)}
              >
                <h5 className="text-lg font-semibold text-gray-800 dark:text-white capitalize">{roleKey}</h5>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDeleteRole(roleKey); }}
                    className="px-3 py-1 text-sm bg-red-100 text-red-800 rounded-md hover:bg-red-200 transition-colors"
                  >
                    Eliminar
                  </button>
                  <span>{expandedRole === roleKey ? '▲' : '▼'}</span>
                </div>
              </div>

              {expandedRole === roleKey && (
                <div className="p-4 border-t border-gray-200 dark:border-gray-600">
                  <h6 className="text-md font-medium text-gray-800 dark:text-white mb-3">Permisos:</h6>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {permissionSections.map(section => (
                      <div key={section} className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-sm">
                        <h6 className="font-semibold text-gray-800 dark:text-white capitalize mb-2">{section}</h6>
                        <div className="flex flex-col space-y-1">
                          {permissionOptions.map(action => (
                            <label key={action} className="inline-flex items-center">
                              <input
                                type="checkbox"
                                checked={roles[roleKey][section]?.[action] || false}
                                onChange={() => handlePermissionChange(roleKey, section, action)}
                                className="h-4 w-4 text-black rounded border-gray-300 focus:ring-black dark:bg-gray-700 dark:border-gray-600"
                              />
                              <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">{action}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {hasChanges && (
          <button
            onClick={handleSaveChanges}
            className="w-full mt-4 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors"
          >
            Guardar Cambios
          </button>
        )}
      </div>
    </div>
  );
};

export default AdminPermissions;