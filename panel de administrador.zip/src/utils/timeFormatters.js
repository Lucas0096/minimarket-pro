// Calcula la diferencia de tiempo desde un timestamp
export const getTimeDifference = (timestamp) => {
  const now = Date.now();
  const diff = now - timestamp;

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days} día${days > 1 ? 's' : ''}`;
  if (hours > 0) return `${hours} hora${hours > 1 ? 's' : ''}`;
  if (minutes > 0) return `${minutes} minuto${minutes > 1 ? 's' : ''}`;
  return `${seconds} segundo${seconds !== 1 ? 's' : ''}`;
};

// Calcula el tiempo restante hasta una fecha de fin
export const getRemainingTime = (endDate) => {
  const now = Date.now();
  const diff = endDate - now;

  if (diff <= 0) return { text: 'Bloqueado', color: 'text-red-600', days: 0, hours: 0, minutes: 0, seconds: 0 };

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  const remainingHours = hours % 24;
  const remainingMinutes = minutes % 60;
  const remainingSeconds = seconds % 60;

  let text = '';
  if (days > 0) text += `${days} día${days > 1 ? 's' : ''} `;
  if (remainingHours > 0) text += `${remainingHours} hr${remainingHours > 1 ? 's' : ''} `;
  if (remainingMinutes > 0) text += `${remainingMinutes} min${remainingMinutes > 1 ? 's' : ''} `;
  if (remainingSeconds > 0 && days === 0 && remainingHours === 0 && remainingMinutes === 0) text += `${remainingSeconds} seg`;

  if (text === '') text = 'Menos de 1 seg';

  return {
    text: text.trim(),
    color: days <= 7 ? 'text-orange-600' : 'text-green-600',
    days: days,
    hours: remainingHours,
    minutes: remainingMinutes,
    seconds: remainingSeconds
  };
};

// Calcula la fecha de vencimiento de la suscripción
export const calculateSubscriptionEndDate = (baseTimestamp, monthsToAdd = 1) => {
  const baseDate = new Date(baseTimestamp);
  let targetMonth = baseDate.getMonth() + monthsToAdd;
  let targetYear = baseDate.getFullYear();

  if (targetMonth > 11) {
    targetYear += Math.floor(targetMonth / 12);
    targetMonth %= 12;
  }

  const newDate = new Date(targetYear, targetMonth, 5);
  newDate.setHours(23, 59, 59, 999);
  return newDate.getTime();
};