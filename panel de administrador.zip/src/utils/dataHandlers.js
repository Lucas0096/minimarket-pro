import { mockData } from '../mock/mockData';

// Simula la obtención de datos
export const getAllData = async (storeName) => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(mockData[storeName] || []);
    }, 100);
  });
};

// Simula la adición de datos
export const addData = async (storeName, data) => {
  return new Promise(resolve => {
    setTimeout(() => {
      mockData[storeName].push(data);
      resolve(data);
    }, 100);
  });
};

// Simula la actualización de datos
export const putData = async (storeName, data) => {
  return new Promise(resolve => {
    setTimeout(() => {
      const index = mockData[storeName].findIndex(item => item.id === data.id);
      if (index !== -1) {
        mockData[storeName][index] = data;
      }
      resolve(data);
    }, 100);
  });
};

// Simula la eliminación de datos
export const deleteData = async (storeName, id) => {
  return new Promise(resolve => {
    setTimeout(() => {
      mockData[storeName] = mockData[storeName].filter(item => item.id !== id);
      resolve();
    }, 100);
  });
};

// Simula la sincronización con IndexedDB
export const syncLocalStorageWithIndexedDB = (storeName, data) => {
  console.log(`Sincronizando ${storeName} con IndexedDB:`, data);
};

// Simula la verificación de rol de administrador
export const isAdmin = () => {
  return true;
};