import React, { useState, useEffect } from 'react';
import { getAllData, addData, putData, deleteData, syncLocalStorageWithIndexedDB, isAdmin } from './utils/dataHandlers';
import { calculateSubscriptionEndDate } from './utils/timeFormatters';
import { mockData } from './mock/mockData';
import { defaultLogs } from './mock/logs';

import AdminMainDashboard from './components/AdminMainDashboard';
import AdminAddMarket from './components/AdminAddMarket';
import AdminAddUser from './components/AdminAddUser';
import AdminUsersList from './components/AdminUsersList';
import AdminPayments from './components/AdminPayments';
import AdminPermissions from './components/AdminPermissions';
import AdminSettings from './components/AdminSettings';
import AdminSubscriptionPlans from './components/AdminSubscriptionPlans';
import AdminTransactionHistory from './components/AdminTransactionHistory';
import AdminLogViewer from './components/AdminLogViewer';
import AdminBackup from './components/AdminBackup';
import AdminSupport from './components/AdminSupport'; // Importar el nuevo componente

const App = () => {
  const [currentView, setCurrentView] = useState('main');
  const [markets, setMarkets] = useState([]);
  const [users, setUsers] = useState([]);
  const [message, setMessage] = useState({ type: '', text: '' });

  const [transactions, setTransactions] = useState([]);
  const [permissionSections, setPermissionSections] = useState([]);
  const [settings, setSettings] = useState({});
  const [subscriptionPlans, setSubscriptionPlans] = useState([]);
  const [roles, setRoles] = useState({});
  const [hasChanges, setHasChanges] = useState(false);

  const [editingUser, setEditingUser] = useState(null);
  const [newMarketName, setNewMarketName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState('vendedor');
  const [selectedMarketForUser, setSelectedMarketForUser] = useState('');

  const [newMarketOwnerName, setNewMarketOwnerName] = useState('');
  const [newMarketOwnerLastName, setNewMarketOwnerLastName] = useState('');
  const [newMarketOwnerDNI, setNewMarketOwnerDNI] = useState('');
  const [newMarketOwnerPhone, setNewMarketOwnerPhone] = useState('');
  const [newMarketOwnerEmail, setNewMarketOwnerEmail] = useState('');
  const [newMarketAddress, setNewMarketAddress] = useState('');
  const [newMarketMapLocation, setNewMarketMapLocation] = useState('');

  const [selectedUserForPermissions, setSelectedUserForPermissions] = useState(null);
  const [newPermissionSectionName, setNewPermissionSectionName] = useState('');
  const [newRoleName, setNewRoleName] = useState('');
  const [editingRole, setEditingRole] = useState(null);

  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanPrice, setNewPlanPrice] = useState('');
  const [newPlanFeatures, setNewPlanFeatures] = useState('');
  const [newPlanMaxUsers, setNewPlanMaxUsers] = useState('');

  const [searchTerm, setSearchTerm] = useState('');

  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      const savedMarkets = await getAllData('markets');
      const savedUsers = await getAllData('users');
      const savedTransactions = await getAllData('transactions');
      const savedPermissionSections = mockData.permissionSections;
      const savedSettings = mockData.settings;
      const savedSubscriptionPlans = await getAllData('subscriptionPlans');
      const savedRoles = mockData.roles;
      const savedLogs = defaultLogs;

      setMarkets(savedMarkets);
      setUsers(savedUsers);
      setTransactions(savedTransactions);
      setPermissionSections(savedPermissionSections);
      setSettings(savedSettings);
      setSubscriptionPlans(savedSubscriptionPlans);
      setRoles(savedRoles);
      setLogs(savedLogs);
    };
    loadData();
  }, []);

  const addLogEntry = (activity, marketId = null, userId = 'admin') => {
    const newLog = {
      id: logs.length + 1,
      date: Date.now(),
      activity,
      marketId,
      userId
    };
    setLogs(prevLogs => [...prevLogs, newLog]);
  };

  const handleAddMarket = async () => {
    if (!newMarketName.trim() || !newMarketOwnerName.trim() || !newMarketOwnerLastName.trim() || !newMarketOwnerDNI.trim() || !newMarketOwnerPhone.trim() || !newMarketOwnerEmail.trim() || !newMarketAddress.trim() || !newMarketMapLocation.trim()) {
      setMessage({ type: 'error', text: 'Todos los campos del mercado son obligatorios.' });
      return;
    }

    const newMarket = {
      id: `market${Date.now()}`,
      name: newMarketName.trim(),
      lastConnection: Date.now(),
      subscriptionEndDate: calculateSubscriptionEndDate(Date.now()),
      ownerName: newMarketOwnerName.trim(),
      ownerLastName: newMarketOwnerLastName.trim(),
      ownerDNI: newMarketOwnerDNI.trim(),
      ownerPhone: newMarketOwnerPhone.trim(),
      ownerEmail: newMarketOwnerEmail.trim(),
      address: newMarketAddress.trim(),
      mapLocation: newMarketMapLocation.trim(),
    };

    const updatedMarkets = [...markets, newMarket];
    await addData('markets', newMarket);
    setMarkets(updatedMarkets);
    syncLocalStorageWithIndexedDB('markets', updatedMarkets);
    setNewMarketName('');
    setNewMarketOwnerName('');
    setNewMarketOwnerLastName('');
    setNewMarketOwnerDNI('');
    setNewMarketOwnerPhone('');
    setNewMarketOwnerEmail('');
    setNewMarketAddress('');
    setNewMarketMapLocation('');
    setMessage({ type: 'success', text: `Mercado "${newMarket.name}" agregado con éxito.` });
    setCurrentView('users');
    addLogEntry(`Mercado "${newMarket.name}" agregado`, newMarket.id);
  };

  const handleAddUser = async () => {
    setMessage({ type: '', text: '' });
    if (!newUsername.trim() || !newPassword.trim() || !selectedMarketForUser || !newUserRole) {
      setMessage({ type: 'error', text: 'Todos los campos de usuario son obligatorios.' });
      return;
    }

    const allUsers = await getAllData('users');
    if (allUsers.some(u => u.username === newUsername.trim())) {
      setMessage({ type: 'error', text: `El usuario "${newUsername.trim()}" ya existe. Por favor, elige otro.` });
      return;
    }

    const newUser = {
      id: Date.now(),
      username: newUsername.trim(),
      password: newPassword.trim(),
      role: newUserRole,
      marketId: selectedMarketForUser,
      accessBlocked: false,
      lastActive: Date.now(),
      permissions: roles[newUserRole] || {}
    };

    const updatedUsers = [...users, newUser];
    await addData('users', newUser);
    setUsers(updatedUsers);
    syncLocalStorageWithIndexedDB('users', updatedUsers);
    resetUserForm();
    setMessage({ type: 'success', text: `Usuario "${newUser.username}" creado con éxito.` });
    setCurrentView('users');
    addLogEntry(`Usuario "${newUser.username}" creado`, newUser.marketId, newUser.username);
  };

  const handleUpdateUser = async () => {
    setMessage({ type: '', text: '' });
    if (!editingUser || !editingUser.username || !editingUser.password || !editingUser.role) {
      setMessage({ type: 'error', text: 'Todos los campos de usuario son obligatorios.' });
      return;
    }

    const updatedUserWithPermissions = {
      ...editingUser,
      permissions: roles[editingUser.role] || {}
    };

    const updatedUsers = users.map(u =>
      u.id === updatedUserWithPermissions.id ? updatedUserWithPermissions : u
    );

    await putData('users', updatedUserWithPermissions);
    setUsers(updatedUsers);
    syncLocalStorageWithIndexedDB('users', updatedUsers);
    handleCancelEdit();
    setMessage({ type: 'success', text: `Usuario "${updatedUserWithPermissions.username}" actualizado con éxito.` });
    addLogEntry(`Usuario "${updatedUserWithPermissions.username}" actualizado`, updatedUserWithPermissions.marketId, updatedUserWithPermissions.username);
  };

  const handleDeleteUser = async (id) => {
    setMessage({ type: '', text: '' });
    const userToDelete = users.find(u => u.id === id);
    if (window.confirm(`¿Estás seguro de que quieres eliminar al usuario "${userToDelete.username}"?`)) {
      await deleteData('users', id);
      const updatedUsers = users.filter(u => u.id !== id);
      setUsers(updatedUsers);
      syncLocalStorageWithIndexedDB('users', updatedUsers);
      setMessage({ type: 'success', text: `Usuario "${userToDelete.username}" eliminado con éxito.` });
      addLogEntry(`Usuario "${userToDelete.username}" eliminado`, userToDelete.marketId, userToDelete.username);
    }
  };

  const handleEditUser = (user) => {
    setEditingUser({ ...user });
    setNewUsername(user.username);
    setNewPassword(user.password);
    setNewUserRole(user.role);
    setSelectedMarketForUser(user.marketId);
    setCurrentView('addUser');
  };

  const handleCancelEdit = () => {
    setEditingUser(null);
    resetUserForm();
    setCurrentView('users');
  };

  const resetUserForm = () => {
    setNewUsername('');
    setNewPassword('');
    setNewUserRole('vendedor');
    setSelectedMarketForUser('');
  };

  const handleMarketAction = async (marketId, actionType, value = null) => {
    setMessage({ type: '', text: '' });
    const marketToUpdate = markets.find(m => m.id === marketId);
    if (!marketToUpdate) return;

    let updatedMarket = { ...marketToUpdate };
    let actionMessage = '';
    let logActivity = '';

    switch (actionType) {
      case 'resetDays':
        updatedMarket.subscriptionEndDate = calculateSubscriptionEndDate(Date.now());
        actionMessage = `Días de suscripción de ${updatedMarket.name} reseteados.`;
        logActivity = `Días de suscripción de "${updatedMarket.name}" reseteados.`;
        break;
      case 'blockAccess':
        updatedMarket.subscriptionEndDate = Date.now() - 1;
        actionMessage = `Acceso de ${updatedMarket.name} bloqueado.`;
        logActivity = `Acceso de "${updatedMarket.name}" bloqueado.`;
        break;
      case 'extendDays':
        const currentEndDate = new Date(updatedMarket.subscriptionEndDate);
        const today = new Date();
        let newEndDateTimestamp;

        if (currentEndDate.getTime() <= today.getTime() || (currentEndDate.getDate() === 5 && currentEndDate.getMonth() <= today.getMonth() && currentEndDate.getFullYear() <= today.getFullYear())) {
          newEndDateTimestamp = calculateSubscriptionEndDate(today.getTime());
        } else {
          newEndDateTimestamp = calculateSubscriptionEndDate(currentEndDate.getTime());
        }
        updatedMarket.subscriptionEndDate = newEndDateTimestamp;
        actionMessage = `Suscripción de ${updatedMarket.name} extendida por 30 días.`;
        logActivity = `Suscripción de "${updatedMarket.name}" extendida por 30 días.`;
        break;
      case 'sendReminder':
        actionMessage = `Recordatorio de pago enviado a ${updatedMarket.name}. (Simulado)`;
        logActivity = `Recordatorio de pago enviado a "${updatedMarket.name}".`;
        break;
      case 'unblockAccess':
        updatedMarket.subscriptionEndDate = calculateSubscriptionEndDate(Date.now());
        actionMessage = `Acceso de ${updatedMarket.name} desbloqueado.`;
        logActivity = `Acceso de "${updatedMarket.name}" desbloqueado.`;
        break;
      default:
        return;
    }

    try {
      await putData('markets', updatedMarket);
      const updatedMarketsList = markets.map(m => m.id === marketId ? updatedMarket : m);
      setMarkets(updatedMarketsList);
      syncLocalStorageWithIndexedDB('markets', updatedMarketsList);
      setMessage({ type: 'success', text: actionMessage });
      addLogEntry(logActivity, updatedMarket.id);
    } catch (error) {
      setMessage({ type: 'error', text: `Error al realizar la acción: ${error.message}` });
    }
  };

  const handleTogglePermission = async (userId, section) => {
    const userToUpdate = users.find(u => u.id === userId);
    if (!userToUpdate) return;

    const updatedPermissions = {
      ...userToUpdate.permissions,
      [section]: !userToUpdate.permissions[section]
    };
    const updatedUser = { ...userToUpdate, permissions: updatedPermissions };

    await putData('users', updatedUser);
    setUsers(prevUsers => prevUsers.map(u => u.id === userId ? updatedUser : u));
    if (selectedUserForPermissions && selectedUserForPermissions.id === userId) {
      setSelectedUserForPermissions(updatedUser);
    }
    syncLocalStorageWithIndexedDB('users', users.map(u => u.id === userId ? updatedUser : u));
    setMessage({ type: 'success', text: `Permiso de ${section} para ${userToUpdate.username} actualizado.` });
    addLogEntry(`Permiso de "${section}" para usuario "${userToUpdate.username}" actualizado.`, userToUpdate.marketId, userToUpdate.username);
  };

  const handleAddPermissionSection = async () => {
    if (!newPermissionSectionName.trim()) {
      setMessage({ type: 'error', text: 'El nombre de la sección no puede estar vacío.' });
      return;
    }
    const normalizedName = newPermissionSectionName.trim().toLowerCase();
    if (permissionSections.includes(normalizedName)) {
      setMessage({ type: 'error', text: `La sección "${normalizedName}" ya existe.` });
      return;
    }

    const updatedSections = [...permissionSections, normalizedName];
    setPermissionSections(updatedSections);

    const updatedRoles = { ...roles };
    Object.keys(updatedRoles).forEach(roleKey => {
      updatedRoles[roleKey][normalizedName] = false;
    });
    setRoles(updatedRoles);

    const updatedUsers = users.map(user => ({
      ...user,
      permissions: {
        ...user.permissions,
        [normalizedName]: false
      }
    }));
    setUsers(updatedUsers);
    if (selectedUserForPermissions) {
      setSelectedUserForPermissions(prevUser => ({
        ...prevUser,
        permissions: {
          ...prevUser.permissions,
          [normalizedName]: false
        }
      }));
    }

    setNewPermissionSectionName('');
    setMessage({ type: 'success', text: `Sección de permiso "${normalizedName}" agregada.` });
    addLogEntry(`Sección de permiso "${normalizedName}" agregada.`);
  };

  const handleRemovePermissionSection = async (sectionToRemove) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar la sección de permiso "${sectionToRemove}"? Esto eliminará el permiso para todos los usuarios y roles.`)) {
      const updatedSections = permissionSections.filter(s => s !== sectionToRemove);
      setPermissionSections(updatedSections);

      const updatedRoles = { ...roles };
      Object.keys(updatedRoles).forEach(roleKey => {
        delete updatedRoles[roleKey][sectionToRemove];
      });
      setRoles(updatedRoles);

      const updatedUsers = users.map(user => {
        const newPermissions = { ...user.permissions };
        delete newPermissions[sectionToRemove];
        return { ...user, permissions: newPermissions };
      });
      setUsers(updatedUsers);
      if (selectedUserForPermissions) {
        setSelectedUserForPermissions(prevUser => {
          const newPermissions = { ...prevUser.permissions };
          delete newPermissions[sectionToRemove];
          return { ...prevUser, permissions: newPermissions };
        });
      }

      setMessage({ type: 'success', text: `Sección de permiso "${sectionToRemove}" eliminada.` });
      addLogEntry(`Sección de permiso "${sectionToRemove}" eliminada.`);
    }
  };

  const handleAddRole = () => {
    if (!newRoleName.trim()) {
      setMessage({ type: 'error', text: 'El nombre del rol no puede estar vacío.' });
      return;
    }
    const normalizedRoleName = newRoleName.trim().toLowerCase();
    if (roles[normalizedRoleName]) {
      setMessage({ type: 'error', text: `El rol "${normalizedRoleName}" ya existe.` });
      return;
    }

    const newRolePermissions = {};
    permissionSections.forEach(section => {
      newRolePermissions[section] = { ver: false, editar: false, eliminar: false }; // Inicializar con granularidad
    });

    setRoles(prevRoles => ({
      ...prevRoles,
      [normalizedRoleName]: newRolePermissions
    }));
    setNewRoleName('');
    setMessage({ type: 'success', text: `Rol "${normalizedRoleName}" agregado con éxito.` });
    addLogEntry(`Rol "${normalizedRoleName}" agregado.`);
  };

  const handleUpdateRole = () => {
    if (!newRoleName.trim()) {
      setMessage({ type: 'error', text: 'El nombre del rol no puede estar vacío.' });
      return;
    }
    const normalizedNewRoleName = newRoleName.trim().toLowerCase();

    if (editingRole && editingRole !== normalizedNewRoleName && roles[normalizedNewRoleName]) {
      setMessage({ type: 'error', text: `El rol "${normalizedNewRoleName}" ya existe.` });
      return;
    }

    setRoles(prevRoles => {
      const updatedRoles = { ...prevRoles };
      if (editingRole && editingRole !== normalizedNewRoleName) {
        updatedRoles[normalizedNewRoleName] = updatedRoles[editingRole];
        delete updatedRoles[editingRole];
        setUsers(prevUsers => prevUsers.map(user =>
          user.role === editingRole ? { ...user, role: normalizedNewRoleName } : user
        ));
      }
      return updatedRoles;
    });
    setEditingRole(null);
    setNewRoleName('');
    setMessage({ type: 'success', text: `Rol "${normalizedNewRoleName}" actualizado con éxito.` });
    addLogEntry(`Rol "${normalizedNewRoleName}" actualizado.`);
  };

  const handleDeleteRole = (roleToDelete) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar el rol "${roleToDelete}"? Esto afectará a todos los usuarios con este rol.`)) {
      setRoles(prevRoles => {
        const updatedRoles = { ...prevRoles };
        delete updatedRoles[roleToDelete];
        return updatedRoles;
      });
      setUsers(prevUsers => prevUsers.map(user =>
        user.role === roleToDelete ? { ...user, role: 'vendedor' } : user
      ));
      setMessage({ type: 'success', text: `Rol "${roleToDelete}" eliminado.` });
      addLogEntry(`Rol "${roleToDelete}" eliminado.`);
    }
  };

  const handleSaveChanges = () => {
    setHasChanges(false);
    setMessage({ type: 'success', text: 'Cambios en roles guardados con éxito.' });
    addLogEntry('Cambios en roles guardados.');
  };

  const handleSettingsChange = (key, value) => {
    setSettings(prevSettings => ({
      ...prevSettings,
      [key]: value
    }));
    setMessage({ type: 'success', text: `Configuración de ${key} actualizada.` });
    addLogEntry(`Configuración de "${key}" actualizada.`);
  };

  const handleImageUpload = (e, key) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleSettingsChange(key, reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpeningHoursChange = (day, index, field, value) => {
    setSettings(prevSettings => {
      const newOpeningHours = { ...prevSettings.openingHours };
      if (!newOpeningHours[day]) {
        newOpeningHours[day] = [];
      }
      if (!newOpeningHours[day][index]) {
        newOpeningHours[day][index] = { start: '', end: '' };
      }
      newOpeningHours[day][index][field] = value;
      return { ...prevSettings, openingHours: newOpeningHours };
    });
  };

  const addTimeSlot = (day) => {
    setSettings(prevSettings => {
      const newOpeningHours = { ...prevSettings.openingHours };
      if (!newOpeningHours[day]) {
        newOpeningHours[day] = [];
      }
      newOpeningHours[day].push({ start: '', end: '' });
      return { ...prevSettings, openingHours: newOpeningHours };
    });
  };

  const removeTimeSlot = (day, index) => {
    setSettings(prevSettings => {
      const newOpeningHours = { ...prevSettings.openingHours };
      newOpeningHours[day].splice(index, 1);
      return { ...prevSettings, openingHours: newOpeningHours };
    });
  };

  const handleAddSubscriptionPlan = async () => {
    if (!newPlanName.trim() || !newPlanPrice.trim() || !newPlanFeatures.trim() || !newPlanMaxUsers.trim()) {
      setMessage({ type: 'error', text: 'Todos los campos del plan son obligatorios.' });
      return;
    }
    const newPlan = {
      id: `plan${Date.now()}`,
      name: newPlanName.trim(),
      price: parseFloat(newPlanPrice),
      features: newPlanFeatures.split(',').map(f => f.trim()),
      maxUsers: parseInt(newPlanMaxUsers),
    };

    const updatedPlans = [...subscriptionPlans, newPlan];
    await addData('subscriptionPlans', newPlan);
    setSubscriptionPlans(updatedPlans);
    setNewPlanName('');
    setNewPlanPrice('');
    setNewPlanFeatures('');
    setNewPlanMaxUsers('');
    setMessage({ type: 'success', text: `Plan "${newPlan.name}" agregado con éxito.` });
    addLogEntry(`Plan de suscripción "${newPlan.name}" agregado.`);
  };

  const handleDeleteSubscriptionPlan = async (id) => {
    if (window.confirm('¿Estás seguro de que quieres eliminar este plan de suscripción?')) {
      await deleteData('subscriptionPlans', id);
      setSubscriptionPlans(subscriptionPlans.filter(plan => plan.id !== id));
      setMessage({ type: 'success', text: 'Plan de suscripción eliminado.' });
      addLogEntry(`Plan de suscripción eliminado (ID: ${id}).`);
    }
  };

  if (!isAdmin()) {
    return <div className="text-center py-10 text-gray-800 dark:text-white">Acceso no autorizado.</div>;
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow-md dark:bg-gray-800">
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-6 text-center">Panel de Administración</h2>

        {message.text && (
          <div className={`p-3 mb-4 rounded-md ${message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {message.text}
          </div>
        )}

        {currentView === 'main' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <button
              onClick={() => setCurrentView('users')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Mercados y Usuarios</span>
              <span className="text-sm mt-2">Ver y gestionar usuarios existentes</span>
            </button>
            <button
              onClick={() => setCurrentView('payments')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Pagos</span>
              <span className="text-sm mt-2">Gestionar estados de pago de mercados</span>
            </button>
            <button
              onClick={() => setCurrentView('permissions')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Permisos y Roles Avanzados</span>
              <span className="text-sm mt-2">Configurar accesos y roles de usuario</span>
            </button>
            <button
              onClick={() => setCurrentView('settings')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Configuración General</span>
              <span className="text-sm mt-2">Personalizar el sistema</span>
            </button>
            <button
              onClick={() => setCurrentView('log')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Log de Actividad</span>
              <span className="text-sm mt-2">Ver registro de todas las acciones</span>
            </button>
            <button
              onClick={() => setCurrentView('backup')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Backup</span>
              <span className="text-sm mt-2">Generar y restaurar copias de seguridad</span>
            </button>
            <button
              onClick={() => setCurrentView('support')}
              className="flex flex-col items-center justify-center p-6 bg-black text-white rounded-lg shadow-lg hover:bg-gray-800 transition-colors h-32"
            >
              <span className="text-2xl font-bold">Soporte y Ayuda</span>
              <span className="text-sm mt-2">Obtener ayuda y contactar soporte</span>
            </button>
          </div>
        )}

        {currentView === 'addMarket' && (
          <AdminAddMarket
            newMarketName={newMarketName} setNewMarketName={setNewMarketName}
            newMarketOwnerName={newMarketOwnerName} setNewMarketOwnerName={setNewMarketOwnerName}
            newMarketOwnerLastName={newMarketOwnerLastName} setNewMarketOwnerLastName={setNewMarketOwnerLastName}
            newMarketOwnerDNI={newMarketOwnerDNI} setNewMarketOwnerDNI={setNewMarketOwnerDNI}
            newMarketOwnerPhone={newMarketOwnerPhone} setNewMarketOwnerPhone={setNewMarketOwnerPhone}
            newMarketOwnerEmail={newMarketOwnerEmail} setNewMarketOwnerEmail={setNewMarketOwnerEmail}
            newMarketAddress={newMarketAddress} setNewMarketAddress={setNewMarketAddress}
            newMarketMapLocation={newMarketMapLocation} setNewMarketMapLocation={setNewMarketMapLocation}
            handleAddMarket={handleAddMarket}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'addUser' && (
          <AdminAddUser
            editingUser={editingUser} setEditingUser={setEditingUser}
            newUsername={newUsername} setNewUsername={setNewUsername}
            newPassword={newPassword} setNewPassword={setNewPassword}
            newUserRole={newUserRole} setNewUserRole={setNewUserRole}
            selectedMarketForUser={selectedMarketForUser} setSelectedMarketForUser={setSelectedMarketForUser}
            markets={markets} roles={roles}
            handleAddUser={handleAddUser} handleUpdateUser={handleUpdateUser} handleCancelEdit={handleCancelEdit}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'users' && (
          <AdminUsersList
            markets={markets} users={users}
            setCurrentView={setCurrentView}
            setEditingUser={setEditingUser} resetUserForm={resetUserForm} setSelectedMarketForUser={setSelectedMarketForUser}
            handleEditUser={handleEditUser} handleDeleteUser={handleDeleteUser}
          />
        )}

        {currentView === 'payments' && (
          <>
            <AdminPayments
              markets={markets} transactions={transactions}
              setCurrentView={setCurrentView}
              handleMarketAction={handleMarketAction}
              setMessage={setMessage}
              putData={putData}
              syncLocalStorageWithIndexedDB={syncLocalStorageWithIndexedDB}
            />
            <AdminSubscriptionPlans
              subscriptionPlans={subscriptionPlans}
              newPlanName={newPlanName} setNewPlanName={setNewPlanName}
              newPlanPrice={newPlanPrice} setNewPlanPrice={setNewPlanPrice}
              newPlanFeatures={newPlanFeatures} setNewPlanFeatures={setNewPlanFeatures}
              newPlanMaxUsers={newPlanMaxUsers} setNewPlanMaxUsers={setNewPlanMaxUsers}
              handleAddSubscriptionPlan={handleAddSubscriptionPlan}
              handleDeleteSubscriptionPlan={handleDeleteSubscriptionPlan}
            />
            <AdminTransactionHistory
              searchTerm={searchTerm} setSearchTerm={setSearchTerm}
              filteredTransactions={transactions.filter(transaction => {
                const market = markets.find(m => m.id === transaction.marketId);
                const ownerName = market ? `${market.ownerName} ${market.ownerLastName}` : '';
                const marketName = market ? market.name : '';
                const transactionDate = new Date(transaction.date).toLocaleDateString();

                return (
                  transactionDate.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  marketName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  ownerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  transaction.operationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  transaction.amount.toString().includes(searchTerm.toLowerCase())
                );
              })}
              markets={markets}
            />
          </>
        )}

        {currentView === 'permissions' && (
          <AdminPermissions
            roles={roles} setRoles={setRoles}
            newRoleName={newRoleName} setNewRoleName={setNewRoleName}
            handleAddRole={handleAddRole} handleUpdateRole={handleUpdateRole} handleDeleteRole={handleDeleteRole}
            editingRole={editingRole} setEditingRole={setEditingRole}
            setCurrentView={setCurrentView}
            hasChanges={hasChanges} setHasChanges={setHasChanges} handleSaveChanges={handleSaveChanges}
          />
        )}

        {currentView === 'settings' && (
          <AdminSettings
            settings={settings}
            handleSettingsChange={handleSettingsChange}
            handleImageUpload={handleImageUpload}
            handleOpeningHoursChange={handleOpeningHoursChange}
            addTimeSlot={addTimeSlot}
            removeTimeSlot={removeTimeSlot}
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'log' && (
          <AdminLogViewer
            setCurrentView={setCurrentView}
            markets={markets}
            users={users}
          />
        )}

        {currentView === 'backup' && (
          <AdminBackup
            setCurrentView={setCurrentView}
            setMessage={setMessage}
          />
        )}

        {currentView === 'support' && (
          <AdminSupport
            setCurrentView={setCurrentView}
          />
        )}
      </div>
    </div>
  );
};

export default App;